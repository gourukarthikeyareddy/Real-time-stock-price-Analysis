import boto3
import json
import psycopg2
from datetime import datetime
import pytz

# RDS Configuration
RDS_HOST = "database-2-instance-1.cxc060m4k7k4.us-east-1.rds.amazonaws.com"  # RDS Endpoint
RDS_PORT = 5432  # Default port for PostgreSQL
RDS_DB = "postgres"  # Database name
RDS_USER = "postgres"  # Database username
RDS_PASSWORD = "Password7"  # Store securely in AWS Secrets Manager

# S3 Configuration
S3_BUCKET = "daily-stock-data-bucket"

# Initialize S3 Client
s3_client = boto3.client("s3")

def get_s3_folder_prefix():
    """
    Dynamically generates the S3 folder prefix based on the current date.
    """
    utc_now = datetime.now(pytz.utc)
    est_now = utc_now.astimezone(pytz.timezone("US/Eastern"))
    date_prefix = est_now.strftime("%Y-%m-%d")
    return f"{date_prefix}/"

def merge_json_files(folder_prefix):
    """
    Merge all JSON files in the specified S3 folder into a single JSON file.
    """
    merged_data = []
    try:
        response = s3_client.list_objects_v2(Bucket=S3_BUCKET, Prefix=folder_prefix)
        files = response.get("Contents", [])

        for file in files:
            key = file["Key"]
            print(f"Reading file: {key}")
            obj = s3_client.get_object(Bucket=S3_BUCKET, Key=key)
            data = json.loads(obj["Body"].read())
            if isinstance(data, list):
                merged_data.extend(data)  # Merge if the file contains a JSON array
            else:
                merged_data.append(data)  # Add if the file contains a single JSON object

        merged_file_key = f"{folder_prefix}merged_stock_data.json"
        s3_client.put_object(
            Bucket=S3_BUCKET,
            Key=merged_file_key,
            Body=json.dumps(merged_data, indent=4),
            ContentType="application/json"
        )
        print(f"Merged JSON saved at: s3://{S3_BUCKET}/{merged_file_key}")
        return merged_file_key
    except Exception as e:
        print(f"Error merging JSON files: {e}")
        raise e

def insert_to_rds(rds_host, s3_file_path):
    """
    Insert data from the merged JSON file in S3 into the RDS PostgreSQL database.
    """
    print("S3 file Path : ", s3_file_path)
    try:
        # Fetch the merged JSON file from S3
        response = s3_client.get_object(Bucket=S3_BUCKET, Key=s3_file_path)
        stock_data = json.loads(response['Body'].read())
        
        # Connect to RDS PostgreSQL
        conn = psycopg2.connect(
            dbname=RDS_DB,
            user=RDS_USER,
            password=RDS_PASSWORD,
            host=rds_host,
            port=RDS_PORT
        )
        cursor = conn.cursor()

        # Insert query
        insert_query = """
        INSERT INTO stock_data (symbol, date, open_price, close_price, high_price, low_price, previous_close_price, timestamp)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        # Prepare the data for batch insert
        data_to_insert = [
            (
                item["symbol"],
                item["date"],
                item["open_price"],
                item["close_price"],
                item["high_price"],
                item["low_price"],
                item["previous_close_price"],
                item["timestamp"]
            )
            for item in stock_data
        ]

        # Execute batch insert
        cursor.executemany(insert_query, data_to_insert)
        conn.commit()
        print(f"Inserted {len(data_to_insert)} records into RDS.")

        # Close the connection
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"Failed to insert data into RDS: {e}")
        raise e

def lambda_handler(event, context):
    """
    Main Lambda function handler.
    """
    # Determine the S3 folder dynamically
    folder_prefix = get_s3_folder_prefix()
    print(f"Processing S3 folder: {folder_prefix}")

    # Merge JSON files
    merged_file_key = merge_json_files(folder_prefix)
    s3_file_path = f"{folder_prefix}merged_stock_data.json"

    print(f"Attempting to load file into RDS: {s3_file_path}")

    # Load data into RDS
    insert_to_rds(RDS_HOST, s3_file_path)

    return {"statusCode": 200, "body": "Data transfer to RDS completed."}