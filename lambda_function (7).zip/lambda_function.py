import json
import boto3
import requests
from datetime import datetime
import pytz

# AWS Configuration
BUCKET_NAME = "daily-stock-data-bucket"  # Replace with your S3 bucket name
s3_client = boto3.client("s3")

FINNHUB_BASE_URL = "https://finnhub.io/api/v1"


def get_secret(secret_name):
    """
    Retrieve secret from AWS Secrets Manager.
    """
    secrets_client = boto3.client("secretsmanager")
    try:
        response = secrets_client.get_secret_value(SecretId=secret_name)
        secret = json.loads(response["SecretString"])
        return secret["FINNHUB_API_KEY"]
    except Exception as e:
        print(f"Failed to retrieve secret: {e}")
        raise e


# Fetch Stock Data using Finnhub.io
def fetch_stock_data(symbol, finnhub_api_key):
    """
    Fetch daily stock price data for a given symbol from Finnhub.io.
    """
    url = f"{FINNHUB_BASE_URL}/quote?symbol={symbol}&token={finnhub_api_key}"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            if data:
                # Transform and include important details
                return {
                    "symbol": symbol,
                    "date": datetime.now(pytz.timezone("US/Eastern")).strftime("%Y-%m-%d"),
                    "open_price": data.get("o"),
                    "close_price": data.get("c"),
                    "high_price": data.get("h"),
                    "low_price": data.get("l"),
                    "previous_close_price": data.get("pc"),
                    "timestamp": data.get("t"),
                }
            else:
                print(f"No data returned for {symbol}")
                return None
        else:
            print(f"Error fetching data for {symbol}: {response.status_code} {response.text}")
            return None
    except Exception as e:
        print(f"Exception occurred while fetching data for {symbol}: {e}")
        return None


# Transform Data
def transform_data(data):
    """
    Check for null values and replace them with default values.
    """
    if not data:
        return None

    # Replace null values with defaults
    data["open_price"] = data["open_price"] if data["open_price"] is not None else 0.0
    data["close_price"] = data["close_price"] if data["close_price"] is not None else 0.0
    data["high_price"] = data["high_price"] if data["high_price"] is not None else 0.0
    data["low_price"] = data["low_price"] if data["low_price"] is not None else 0.0
    data["previous_close_price"] = (
        data["previous_close_price"] if data["previous_close_price"] is not None else 0.0
    )
    data["timestamp"] = data["timestamp"] if data["timestamp"] is not None else 0
    return data


# Save Data to S3
def save_to_s3(data, symbol):
    """
    Save JSON data to an S3 bucket in a folder named after the execution date.
    """
    utc_now = datetime.now(pytz.utc)
    est_now = utc_now.astimezone(pytz.timezone("US/Eastern"))
    date_folder = est_now.strftime("%Y-%m-%d")

    file_name = f"{date_folder}/{symbol}_stock_prices.json"
    try:
        s3_client.put_object(
            Bucket=BUCKET_NAME,
            Key=file_name,
            Body=json.dumps(data, indent=4),
            ContentType="application/json",
        )
        print(f"Uploaded stock prices for {symbol} to S3: {file_name}")
    except Exception as e:
        print(f"Failed to upload data for {symbol} to S3: {e}")


# Lambda Handler
def lambda_handler(event, context):
    """
    Main Lambda function handler.
    """
    try:
        # Retrieve API key from AWS Secrets Manager
        finnhub_api_key = get_secret("FINNHUB_API_KEY")  # Replace with your secret name

        # Top 50 company symbols
        company_symbols = [
            "AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "NVDA", "BRK-B", "META", "V", "UNH",
            "JNJ", "XOM", "JPM", "PG", "PYPL", "TSM", "NSRGY", "RHHBY", "CVX", "LLY",
            "WMT", "MA", "PFE", "KO", "PEP", "DIS", "CSCO", "CMCSA", "ADBE", "NFLX",
            "INTC", "ORCL", "COST", "AVGO", "NKE", "TXN", "QCOM", "MDT", "HON", "AMAT",
            "CRM", "ABBV", "ACN", "BMY", "LIN", "MRK", "PM", "NEE", "IBM", "TMO", "ASML",
        ]

        for symbol in company_symbols:
            print(f"Processing symbol: {symbol}")
            data = fetch_stock_data(symbol, finnhub_api_key)
            if data:
                transformed_data = transform_data(data)  # Apply transformations
                save_to_s3(transformed_data, symbol)

        return {
            "statusCode": 200,
            "body": "Stock data fetched, transformed, and uploaded successfully.",
        }
    except Exception as e:
        print(f"Error in Lambda handler: {e}")
        return {
            "statusCode": 500,
            "body": f"An error occurred: {e}",
        }